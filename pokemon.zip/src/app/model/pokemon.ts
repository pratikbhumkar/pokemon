export class Pokemon {
    id: number;
    name: string;
    power: string;
}
